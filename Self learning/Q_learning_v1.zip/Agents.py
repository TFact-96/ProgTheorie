import random
import numpy as np

np.random.seed(42)

class PassiveTDAgent:
    def __init__(self, discountFactor=1):
        self.utilityTable = {}
        self.policyStates = {}
        self.frequencyTable = {}
        self.previousState = ''
        self.previousAction = ''
        self.previousReward = 0
        self.discountFactor = discountFactor
        self.trials = 0

    def PerceiveAndAct(self, actions):
        unchanged = True
        while unchanged:
            for policy in self.policyStates:
                actionUtilities = {}
                try:
                    actionUtilities['S'] = (self.utilityTable[self.previousState + 'S'])
                except:
                    actionUtilities['S'] = 0
                try:
                    actionUtilities['L'] = (self.utilityTable[self.previousState + 'L'])
                except:
                    actionUtilities['L'] = 0
                try:
                    actionUtilities['R'] = (self.utilityTable[self.previousState + 'R'])
                except:
                    actionUtilities['R'] = 0

                bestUtility = min(actionUtilities)

                if actionUtilities[bestUtility] < self.utilityTable[self.previousState]:
                    unchanged = False
        return policy

    def ProcessReward(self, currentReward, stateAfterAction):
        # Check if we have a new state
        if stateAfterAction not in self.utilityTable.keys():
            self.utilityTable[stateAfterAction] = currentReward
            self.frequencyTable[stateAfterAction] = 0

        if self.previousState != '':
            self.frequencyTable[self.previousState] += 1
            self.utilityTable[self.previousState] += self.StepSize() * (
                    self.previousReward + self.discountFactor * self.utilityTable[stateAfterAction] -
                    self.utilityTable[self.previousState])

        self.previousState = stateAfterAction
        self.previousReward = currentReward

    def StepSize(self):
        return 60 / (59 + self.frequencyTable[self.previousState])

    def ActionPolicy(self, actions):
        self.previousAction = actions[random.randint(0, len(actions) - 1)]
        return self.previousAction

    def Terminate(self):
        self.trials += 1
        return self.trials > 100


class QLearningAgent:
    def __init__(self, discountFactor=1):
        self.QTable = {}
        self.frequencyTable = {}
        self.previousState = ''
        self.previousAction = ''
        self.previousReward = 0
        self.discountFactor = discountFactor
        self.trials = 0
        self.Ne = 10

    def PerceiveAndAct(self, protein, currentReward):
        highest = {}
        PossibleActions = protein.actions
        stateAfterAction = protein.getCompactState()

        # Check if we have a new state
        if self.previousState not in self.QTable.keys():
            self.QTable[self.previousState] = currentReward
            self.frequencyTable[self.previousState] = 0

        if self.previousState != '':
            self.frequencyTable[self.previousState] += 1
            self.QTable[self.previousState] += self.StepSize() * (self.frequencyTable[self.previousState]) * (
                    currentReward + self.discountFactor * self.QTable[stateAfterAction] -
                    self.QTable[self.previousState])

        print(f"possible actions: {PossibleActions}")
        for action in PossibleActions:
            try:
                next_move = self.QTable[stateAfterAction + action]
            except KeyError as e:
                next_move = str(e)
            try:
                freq = self.frequencyTable[stateAfterAction + action]
            except KeyError:
                freq = 0

            print(f"next move: {next_move}")
            highest[stateAfterAction + action] = self.exploration(next_move, freq)

        action = min(highest)
        print(action)

        self.previousState = stateAfterAction
        self.previousReward = currentReward

        return action

    def exploration(self, q, freq):
        if freq < self.Ne:
            if len(q) < 4:
                return - np.random.random_sample()
            elif 4 <= len(q) < 5:
                return -1
            else:
                return -2
        else:
            return q

    def StepSize(self):
        return 60 / (59 + self.frequencyTable[self.previousState])

    def terminate(self):
        self.trials += 1
        return self.trials > 100
